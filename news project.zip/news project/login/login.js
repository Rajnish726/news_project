const logindiv = document.querySelector('.logindiv');
function login (e) {
    console.log(e);
    const html = `

    <form action="" >
        

    <label for="ephn"><h4>Email or Phone:</h4></label><br>
    <input type="email , tel" id="ephn" name="ephn" value=""><br>
    <label for="pwd" id="pwd"><h4>Password</h4></label><br>
    <input type="password" id="pwd" name="pwd" value=""><br>
    <button class="submitbtn"><h3>Submit</h3></button> 
 
</div>
    `;
    logindiv.innerHTML = '';
    logindiv.insertAdjacentHTML('afterbegin',html);
    logindiv.classList.add('active');
    
   
};

document.body.addEventListener('click',closeLoginForm);
function closeLoginForm(event){
    console.log();
    if(!event.target.closest('.logindiv') && !event.target.closest('.loginbutton') ){
        if(logindiv.classList.contains('active')){
            logindiv.classList.remove('active');
        }

    }

}